<?php if (isset($component)) { $__componentOriginal66080d40165dc237152ede315c1d0309 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66080d40165dc237152ede315c1d0309 = $attributes; } ?>
<?php $component = App\View\Components\ErrorLayout::resolve(['code' => 404] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ErrorLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <img src="<?php echo e(asset('images/errors/404.png')); ?>" alt="404 <?php echo app('translator')->get('locale.error', ['suffix'=>'']); ?>" class="img-fluid">
    <div class="mt-5 pt-5 text-center">
        <a class="btn btn-primary waves-effect waves-light" href="<?php echo e(url()->previous()); ?>"><?php echo app('translator')->get('locale.go_to_back'); ?></a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $attributes = $__attributesOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__attributesOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66080d40165dc237152ede315c1d0309)): ?>
<?php $component = $__componentOriginal66080d40165dc237152ede315c1d0309; ?>
<?php unset($__componentOriginal66080d40165dc237152ede315c1d0309); ?>
<?php endif; ?>



<?php /**PATH C:\laragon\www\agristock.com\resources\views/errors/404.blade.php ENDPATH**/ ?>