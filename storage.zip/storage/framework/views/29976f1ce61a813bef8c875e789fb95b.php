<div class="modal fade" id="new-rotten<?php echo e($detail->id); ?>">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger-subtle">
                <h5 class="modal-title"><?php echo app('translator')->get('locale.rotten', ['suffix'=>'']); ?></h5>
            </div>
            <form action="<?php echo e(route('rottens.store')); ?>" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="detail_id" value="<?php echo e($detail->id); ?>"/>
                    <input type="hidden" name="stock_id" value="<?php echo e($detail->stock->id); ?>"/>
                    <div class="d-grid gap-3">                       
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($detail->qty); ?>" name="before_qty" readonly/> <label for="floatingInput"><?php echo app('translator')->get('locale.before_qty'); ?> (kg) <span class="text-danger">*</span></label>
                                </div> 
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="after_qty" min="0" max="<?php echo e($detail->qty); ?>" readonly/> <label for="floatingInput"><?php echo app('translator')->get('locale.after_qty'); ?> (kg) <span class="text-danger">*</span></label>
                                </div> 
                            </div>                        
                            <div class="col-12 mt-3">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="qty" placeholder="Ex: 37 | Max: <?php echo e($detail->qty); ?>" min="1" max="<?php echo e($detail->qty); ?>" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.qty'); ?> (kg) <span class="text-danger">*</span></label>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"><button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button></div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/new-rotten.blade.php ENDPATH**/ ?>