<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta content="Cool AgriStock, Food Storage" name="description" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta content="Cool AgriStock" name="author" />

        <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo app('translator')->get('locale.error', ['suffix'=>'s']); ?> <?php echo e($code); ?></title>

        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">

        <script src="<?php echo e(asset('js/pages/layout.js')); ?>"></script>

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('libs/simplebar/simplebar.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div class="">
            <div class="container">
                <div class="row justify-content-center align-items-center min-vh-100">
                    <div class="col-lg-5">
                        <div class="text-center">
                            <?php echo e($slot); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/metismenu/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/node-waves/waves.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/layouts/error.blade.php ENDPATH**/ ?>