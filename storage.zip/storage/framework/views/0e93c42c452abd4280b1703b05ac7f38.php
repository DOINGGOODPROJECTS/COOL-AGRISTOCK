<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
    <link href="<?php echo e(asset('libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"><?php echo app('translator')->get('locale.incident', ['suffix'=>'s']); ?></h4>

                <div class="page-title-right">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#new-incident"><i class="fas fa-exclamation-triangle"></i> <?php echo app('translator')->get('locale.new', ['param'=>__('locale.incident', ['suffix'=>''])]); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="datatable-footer-callback" class="table table-sm table-hover table-bordered table-striped dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th>#</th>
                            <th><?php echo app('translator')->get('locale.status'); ?></th>
                            <th><?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?></th>
                            <th><?php echo app('translator')->get('locale.description'); ?></th>
                            <th><?php echo app('translator')->get('locale.actions'); ?></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td><?php echo e($item->type); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td>
                                    <?php if($item->status == 'EN COURS'): ?>
                                    <a style="display: inline-block" class="btn btn-label-primary" href="<?php echo e(route('incidents.status', ['status'=>'RESOLU', 'id'=>$item->id])); ?>"><i class="fas fa-check"></i></a>
                                    <a style="display: inline-block" class="btn btn-label-danger" href="<?php echo e(route('incidents.status', ['status'=>'NON RESOLU', 'id'=>$item->id])); ?>"><i class="fas fa-ban"></i></a>
                                    <?php endif; ?>
                                    <a style="display: inline-block" class="btn btn-label-info" data-bs-toggle="modal" data-bs-target="#edit-incident<?php echo e($item->id); ?>"><i class="fas fa-edit"></i></a>
                                    <?php if (isset($component)) { $__componentOriginalbb207f26cd5d1076004cd8bc65419cec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb207f26cd5d1076004cd8bc65419cec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-incident','data' => ['incident' => $item]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('edit-incident'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['incident' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb207f26cd5d1076004cd8bc65419cec)): ?>
<?php $attributes = $__attributesOriginalbb207f26cd5d1076004cd8bc65419cec; ?>
<?php unset($__attributesOriginalbb207f26cd5d1076004cd8bc65419cec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb207f26cd5d1076004cd8bc65419cec)): ?>
<?php $component = $__componentOriginalbb207f26cd5d1076004cd8bc65419cec; ?>
<?php unset($__componentOriginalbb207f26cd5d1076004cd8bc65419cec); ?>
<?php endif; ?>
                                    <form action="<?php echo e(route('incidents.destroy', $item->id)); ?>" method="post" style="display: inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-label-danger" onclick="if(!confirm('Confirmez-Vous cette Suppression ?')) return false"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->

    <div class="modal fade" id="new-incident">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-primary-subtle">
                    <h5 class="modal-title"><?php echo app('translator')->get('locale.incident', ['suffix'=>'']); ?></h5>
                </div>
                <form action="<?php echo e(route('incidents.store')); ?>" method="post">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="d-grid gap-3">
                            <div class="form-floating">
                                <select class="form-select" name="type" aria-label="<?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?>" required>
                                    <?php $__currentLoopData = ['INCIDENT SPECIFIQUE', 'INCIDENT GENERAL']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="type"><?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?> <span class="text-danger">*</span></label>
                            </div> 
                            <div>
                                <label for="message" class="form-label"><?php echo app('translator')->get('locale.message'); ?> <span class="text-danger">*</span></label> 
                                <textarea class="form-control" name="description" id="description" rows="3" style="resize: none"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> 
                        <button class="btn btn-outline-danger" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/pages/datatables-advanced.init.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/admin/incidents.blade.php ENDPATH**/ ?>