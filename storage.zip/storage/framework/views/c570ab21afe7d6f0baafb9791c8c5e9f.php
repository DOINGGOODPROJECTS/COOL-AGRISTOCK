<div class="modal fade" id="edit-incident<?php echo e($incident->id); ?>">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header bg-info-subtle">
                <h5 class="modal-title"><?php echo app('translator')->get('locale.incident', ['suffix'=>'']); ?></h5>
            </div>
            <form action="<?php echo e(route('incidents.update', $incident->id)); ?>" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="d-grid gap-3">
                        <div class="form-floating">
                            <select class="form-select" name="type" aria-label="<?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?>" required>
                                <?php $__currentLoopData = ['INCIDENT SPECIFIQUE', 'INCIDENT GENERAL']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item); ?>" <?php echo e($item == $incident->type ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="type"><?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?></label>
                        </div> 
                        <div>
                            <label for="message" class="form-label"><?php echo app('translator')->get('locale.message'); ?></label> 
                            <textarea class="form-control" name="description" id="description" rows="3" style="resize: none"><?php echo e($incident->message); ?></textarea>
                        </div>                   
                    </div>
                </div>
                <div class="modal-footer"><button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button></div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/edit-incident.blade.php ENDPATH**/ ?>