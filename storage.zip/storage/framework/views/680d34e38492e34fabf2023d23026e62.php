<div class="sidebar-left">
    <div data-simplebar class="h-100">
        <!--- Sidebar-menu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="left-menu list-unstyled" id="side-menu">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="">
                        <i class="fas fa-desktop"></i> <span><?php echo app('translator')->get('locale.dashboard'); ?></span>
                    </a>
                </li>
                
                <li class="menu-title"><?php echo app('translator')->get('locale.management'); ?></li>
                
                <?php if(isGroupAuthorized([1, 2])): ?>
                <li><a href="<?php echo e(route('customers')); ?>"><i class="fa fa-users"></i> <span><?php echo app('translator')->get('locale.customer', ['suffix'=>'s']); ?></span></a></li>
                <li><a href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-dumpster"></i> <span><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'ies' : 's']); ?></span></a></li>
                <li><a href="<?php echo e(route('incidents.index')); ?>"><i class="fas fa-exclamation-triangle"></i> <span><?php echo app('translator')->get('locale.incident', ['suffix'=>'s']); ?></span></a></li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="fa fa-folder"></i> <span><?php echo app('translator')->get('locale.user', ['suffix'=>'s']); ?></span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('groups')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i><?php echo app('translator')->get('locale.group', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('users.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.user', ['suffix'=>'s']); ?></a></li>
                    </ul>
                </li>
                <?php endif; ?>    

                <?php if(isGroupAuthorized([1, 2, 5, 6, 7, 8])): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="fa fa-folder"></i> <span><?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?></span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <?php if(isGroupAuthorized([1, 2])): ?>
                        <li><a href="<?php echo e(route('storages.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.storage', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('temperatures.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i><?php echo app('translator')->get('locale.temperature', ['suffix'=>'s']); ?></a></li>
                        <?php endif; ?>

                        <li><a href="<?php echo e(route('stocks.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('releases.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.release', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('rottens.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.rotten', ['suffix'=>'s']); ?></a></li>
                    
                        <?php if(isGroupAuthorized([1, 2])): ?>
                        <li><a href="<?php echo e(route('capacities.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.capacity', ['suffix'=>app()->getLocale() == 'en' ? 'ies' : 's']); ?></a></li>
                        <li><a href="<?php echo e(route('products.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.product', ['suffix'=>'s']); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>  
                
                <?php if(isGroupAuthorized([1, 3, 4, 5, 6, 7, 8])): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="fa fa-folder"></i> <span><?php echo app('translator')->get('locale.accounting', ['suffix'=>'']); ?></span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('billings.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i><?php echo app('translator')->get('locale.billing', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('payments.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.payment', ['suffix'=>'s']); ?></a></li>
                        <li><a href="<?php echo e(route('tariffs.index')); ?>"><i class="mdi mdi-checkbox-blank-circle align-middle"></i> <?php echo app('translator')->get('locale.tariff', ['suffix'=>'s']); ?></a></li>
                    </ul>
                </li>
                <?php endif; ?>  

                <li><a href="<?php echo e(route('logout')); ?>" class="text-danger"><i class="fa fa-power-off"></i> <span><?php echo app('translator')->get('locale.logout'); ?></span></a></li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/sidebar.blade.php ENDPATH**/ ?>