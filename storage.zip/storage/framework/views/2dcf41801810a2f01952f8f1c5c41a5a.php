<div class="modal fade" id="edit-product<?php echo e($product->id); ?>">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info-subtle">
                <h5 class="modal-title"><?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?></h5>
            </div>
            <form action="<?php echo e(route('products.update', $product->id)); ?>" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="d-grid gap-3">
                        <div class="form-floating">
                            <input type="text" class="form-control" value="<?php echo e($product->name); ?>" name="name" placeholder="Ex: Banane" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.name'); ?><span class="text-danger">*</span></label>
                        </div> 
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($product->min_expired_at); ?>" name="min_expired_at" placeholder="Ex: 10" required/> <label for="floatingInput">Min <?php echo app('translator')->get('locale.expired_at'); ?> (<?php echo app('translator')->get('locale.days'); ?>)<span class="text-danger">*</span></label>
                                </div> 
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($product->max_expired_at); ?>" name="max_expired_at" placeholder="Ex: 10"/> <label for="floatingInput">Max <?php echo app('translator')->get('locale.expired_at'); ?> (<?php echo app('translator')->get('locale.days'); ?>)</label>
                                </div> 
                            </div>
                        </div>
                        <div class="form-floating">
                            <select class="form-select" name="category_id" aria-label="<?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?>" required>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $product->category_id); ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="cityId"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?> <span class="text-danger">*</span></label>
                        </div> 
                    </div>
                </div>
                <div class="modal-footer"><button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button></div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/edit-product.blade.php ENDPATH**/ ?>