<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
    <link href="<?php echo e(asset('libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'s']); ?></h4>

                <div class="page-title-right">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#new-temperature"><i class="fas fa-cart-plus"></i> <?php echo app('translator')->get('locale.new', ['param'=>__('locale.temperature', ['suffix'=>''])]); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="datatable-footer-callback" class="table table-hover table-bordered table-striped dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th>#</th>
                            <th><?php echo app('translator')->get('locale.created_at'); ?></th>
                            <th><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?></th>
                            <th><?php echo app('translator')->get('locale.session'); ?></th>
                            <th><?php echo app('translator')->get('locale.session_time'); ?></th>
                            <th><?php echo app('translator')->get('locale.temperature', ['suffix'=>'']); ?></th>
                            <th><?php echo app('translator')->get('locale.actions'); ?></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $temperatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginal928c7196944c6d9654f945bb52e0f16a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal928c7196944c6d9654f945bb52e0f16a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-temperature','data' => ['temperature' => $item,'storages' => $storages]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('edit-temperature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['temperature' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item),'storages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($storages)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal928c7196944c6d9654f945bb52e0f16a)): ?>
<?php $attributes = $__attributesOriginal928c7196944c6d9654f945bb52e0f16a; ?>
<?php unset($__attributesOriginal928c7196944c6d9654f945bb52e0f16a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal928c7196944c6d9654f945bb52e0f16a)): ?>
<?php $component = $__componentOriginal928c7196944c6d9654f945bb52e0f16a; ?>
<?php unset($__componentOriginal928c7196944c6d9654f945bb52e0f16a); ?>
<?php endif; ?>

                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at))); ?></td>
                                <td><?php echo e($item->storage->name." - ".$item->storage->location); ?></td>
                                <td><?php echo e($item->session); ?></td>
                                <td><?php echo e(date('H:i', strtotime($item->session_time))); ?></td>
                                <td><?php echo e($item->degree); ?> °C</td>
                                <td>
                                    <a style="display: inline-block" class="btn btn-label-info" data-bs-toggle="modal" data-bs-target="#edit-temperature<?php echo e($item->id); ?>"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('temperatures.destroy', $item->id)); ?>" method="post" style="display: inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-label-danger" onclick="if(!confirm('Confirmez-Vous cette Suppression ?')) return false"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->

    <div class="modal fade" id="new-temperature">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary-subtle">
                    <h5 class="modal-title"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'']); ?></h5>
                </div>
                <form action="<?php echo e(route('temperatures.store')); ?>" method="post">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="d-grid gap-3">
                            <div class="form-floating">
                                <select class="form-select" name="session" aria-label="<?php echo app('translator')->get('locale.session'); ?>" required>
                                    <?php $__currentLoopData = ['PASSAGE 1', 'PASSAGE 2', 'PASSAGE 3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="cityId"><?php echo app('translator')->get('locale.session'); ?> <span class="text-danger">*</span></label>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" id="degree" name="degree" placeholder="Ex: 37" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'']); ?> (°C) <span class="text-danger">*</span></label>
                                    </div> 
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <div class="form-floating">
                                        <input type="time" class="form-control" id="session_time" name="session_time" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.session_time'); ?><span class="text-danger">*</span></label>
                                    </div> 
                                </div>
                            </div>
                            <div class="form-floating">
                                <select class="form-select" name="storage_id" aria-label="<?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?>" required>
                                    <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name." - ".$item->location); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="cityId"><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?> <span class="text-danger">*</span></label>
                            </div>  
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> 
                        <button class="btn btn-outline-danger" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/pages/datatables-advanced.init.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/admin/temperatures.blade.php ENDPATH**/ ?>