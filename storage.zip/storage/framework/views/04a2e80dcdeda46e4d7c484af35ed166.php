<div class="modal fade" id="edit-capacity<?php echo e($capacity->id); ?>">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header bg-info-subtle">
                <h5 class="modal-title"><?php echo app('translator')->get('locale.capacity', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?></h5>
            </div>
            <form action="<?php echo e(route('capacities.update', $capacity->id)); ?>" method="post">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="d-grid gap-3">
                        <div class="form-floating">
                            <input type="text" class="form-control" value="<?php echo e($capacity->name); ?>" name="name" placeholder="Ex: Legumes" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.name'); ?></label>
                        </div>                    
                    </div>
                </div>
                <div class="modal-footer"><button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button></div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/edit-capacity.blade.php ENDPATH**/ ?>