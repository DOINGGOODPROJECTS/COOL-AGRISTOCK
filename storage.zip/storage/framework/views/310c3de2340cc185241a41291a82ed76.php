<div class="modal fade" id="edit-temperature<?php echo e($temperature->id); ?>">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info-subtle">
                <h5 class="modal-title"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'']); ?></h5>
            </div>
            <form action="<?php echo e(route('temperatures.update', $temperature->id)); ?>" method="post">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="modal-body">                    
                    <div class="d-grid gap-3">                        
                        <div class="form-floating">
                            <select class="form-select" name="session" aria-label="<?php echo app('translator')->get('locale.session'); ?>" required>
                                <?php $__currentLoopData = ['PASSAGE 1', 'PASSAGE 2', 'PASSAGE 3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item); ?>" <?php echo e($temperature->session == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="session"><?php echo app('translator')->get('locale.session'); ?> <span class="text-danger">*</span></label>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($temperature->degree); ?>" name="degree" placeholder="Ex: 37" required/> 
                                    <label for="floatingInput"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'']); ?> (°C) <span class="text-danger">*</span></label>
                                </div> 
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="time" class="form-control" value="<?php echo e($temperature->session_time); ?>" name="session_time" required/> 
                                    <label for="floatingInput"><?php echo app('translator')->get('locale.session_time'); ?><span class="text-danger">*</span></label>
                                </div> 
                            </div>
                        </div>
                        <div class="form-floating">
                            <select class="form-select" name="storage_id" aria-label="<?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?>" required>
                                <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($temperature->storage_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name." - ".$item->location); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="storageId"><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?> <span class="text-danger">*</span></label>
                        </div>  
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> 
                    <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/edit-temperature.blade.php ENDPATH**/ ?>