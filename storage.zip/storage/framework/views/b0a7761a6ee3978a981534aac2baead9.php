<form action="<?php echo e(route('stocks.update', $stock->id)); ?>" method="post" style="display: inline-block">
    <div class="modal fade" id="edit-stock<?php echo e($stock->id); ?>">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-header bg-info-subtle">
                    <h5 class="modal-title"><?php echo app('translator')->get('locale.stock', ['suffix'=>'']); ?></h5>
                </div>
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="d-grid gap-3">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($stock->qty); ?>" name="qty" placeholder="Ex: 20" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.qty'); ?> (t)</label>
                                </div>                                  
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <input type="number" class="form-control" value="<?php echo e($stock->expired_at); ?>" name="expired_at" placeholder="Ex: 30" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.storage_duration'); ?></label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <select class="form-select" name="customer_id" aria-label="<?php echo app('translator')->get('locale.city', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?>" required>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $stock->customer_id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="customerId"><?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?></label>
                                </div>                                
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-floating">
                                    <select class="form-select" name="storage_id" aria-label="<?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?>" required>
                                        <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $stock->storage_id ? 'selected' : ''); ?> title="<?php echo e($item->expired_at); ?>"><?php echo e($item->location." - ".$item->type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="storageId"><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?></label>
                                </div>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="modal-footer"><button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> <button class="btn btn-outline-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button></div>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/components/edit-stock.blade.php ENDPATH**/ ?>