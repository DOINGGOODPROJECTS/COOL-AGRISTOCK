<div class="row">
    <div class="col-xxl-9">
        <div class="row">
            <div class="col-xl-4 col-md-4 col-sm-4 col-xs-12">
                <div class="card bg-danger-subtle" style="background: url(<?php echo e(asset('images/dashboard/dashboard-shape-1.png')); ?>); background-repeat: no-repeat; background-position: bottom center; ">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="avatar avatar-sm avatar-label-danger">
                                <i class="mdi mdi-buffer mt-1"></i>
                            </div>
                            <div class="ms-3">
                                <p class="text-danger mb-1"><?php echo app('translator')->get('locale.billing', ['suffix'=>'s']); ?></p>
                                <h4 class="mb-0"><?php echo e(moneyFormat($billings->sum('amount'))); ?></h4>
                            </div>
                        </div>
                        <div class="mt-3 mb-2">
                            <p class="mb-0"><?php echo app('translator')->get('locale.total'); ?> : <?php echo e($billings->count()); ?></p>                                
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-4 col-sm-4 col-xs-12">
                <div class="card bg-success-subtle" style="background: url(<?php echo e(asset('images/dashboard/dashboard-shape-2.png')); ?>); background-repeat: no-repeat; background-position: bottom center; ">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="avatar avatar-sm avatar-label-success">
                                <i class="mdi mdi-cash-usd-outline mt-1"></i>
                            </div>
                            <div class="ms-3">
                                <p class="text-success mb-1"><?php echo app('translator')->get('locale.payment', ['suffix'=>'s']); ?></p>
                                <h4 class="mb-0"><?php echo e(moneyFormat($payments->sum('amount'))); ?></h4>
                            </div>
                        </div>
                        <div class="mt-3 mb-2">
                            <p class="mb-0"><?php echo app('translator')->get('locale.total'); ?> : <?php echo e($payments->count()); ?></p>                                
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-4 col-sm-4 col-xs-12">
                <div class="card bg-info-subtle" style="background: url(<?php echo e(asset('images/dashboard/dashboard-shape-3.png')); ?>); background-repeat: no-repeat; background-position: bottom center; ">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="avatar avatar-sm avatar-label-info">
                                <i class="mdi mdi-webhook mt-1"></i>
                            </div>
                            <div class="ms-3">
                                <p class="text-info mb-1"><?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?></p>
                                <h4 class="mb-0"><?php echo e($stocks->count()); ?></h4>
                            </div>
                        </div>
                        <div class="hstack gap-2 mt-3">
                            <?php if(isGroupAuthorized([5, 6, 7, 8])): ?>
                            <button class="btn btn-primary"><?php echo app('translator')->get('locale.delivery', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?></button>
                            <button class="btn btn-danger"><?php echo app('translator')->get('locale.filter'); ?></button>
                            <?php else: ?>
                            <p class="mb-2"><?php echo e($releases->count()); ?> <?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?> <?php echo app('translator')->get('locale.released'); ?></p>
                            <?php endif; ?>                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-md-8 col-sm-8 col-xs-12">
                <div class="card border">
                    <div class="card-header bg-success-subtle">
                        <h3 class="card-title">
                            <i class="fas fa-cart-plus fs-14 text-muted"></i> 10 <?php echo app('translator')->get('locale.last_stocks'); ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover table-bordered table-striped dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <th>#</th>
                                    <th><?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?></th>
                                    <th><?php echo app('translator')->get('locale.ref'); ?></th>
                                    <th><?php echo app('translator')->get('locale.billing', ['suffix'=>'']); ?></th>
                                    <th><?php echo app('translator')->get('locale.qty'); ?></th>
                                    <th><?php echo app('translator')->get('locale.expired_at'); ?></th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->customer->name); ?></td>
                                        <td><?php echo e($item->ref); ?></td>
                                        <td><?php echo e($item->billing->ref); ?></td>
                                        <td><?php echo e($item->qty); ?> kg</td>
                                        <td class="text-<?php echo e($item->created_at->addDays($item->expired_at) >= now() ? 'primary' : 'danger'); ?>">
                                            <?php if($item->qty == 0): ?>
                                                <div class="text-primary text-italic"><?php echo app('translator')->get('locale.released'); ?></div>
                                            <?php else: ?>
                                                <?php echo e(date('d/m/Y', strtotime($item->created_at->addDays($item->expired_at))) ." / ".$item->expired_at); ?> <?php echo app('translator')->get('locale.days'); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="card">
                    <div class="card-header card-header-bordered bg-danger-subtle">
                        <h3 class="card-title">
                            <i class="fas fa-exclamation-triangle"></i>
                            <?php echo app('translator')->get('locale.incident', ['suffix'=>'s']); ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="slider responsive slick-initialized slick-slider slick-dotted"><button class="slick-prev slick-arrow" aria-label="Previous" type="button" style="">Previous</button>
                        <div class="slick-list draggable">
                            <div class="slick-track" style="opacity: 1; width: 6804px; transform: translate3d(-2268px, 0px, 0px);">
                                <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="slick-slide slick-cloned" tabindex="-1" role="tabpanel" style="width: 236px;" data-slick-index="<?php echo e($item->id); ?>" aria-hidden="true">
                                    <div class="card mb-0">
                                        <p class="text-muted"><?php echo e($item->description); ?></p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <button class="slick-next slick-arrow" aria-label="Next" type="button" style="">Next</button><ul class="slick-dots" style="" role="tablist"><li class="" role="presentation"><button type="button" role="tab" id="slick-slide-control20" aria-controls="slick-slide20" aria-label="1 of 4" tabindex="-1">1</button></li><li role="presentation"><button type="button" role="tab" id="slick-slide-control21" aria-controls="slick-slide23" aria-label="2 of 4" tabindex="-1">2</button></li><li class="slick-active" role="presentation"><button type="button" role="tab" id="slick-slide-control22" aria-controls="slick-slide26" aria-label="3 of 4" tabindex="-1">3</button></li><li role="presentation"><button type="button" role="tab" id="slick-slide-control23" aria-controls="slick-slide29" aria-label="4 of 4" tabindex="-1">4</button></li></ul></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row -->

<div class="row">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header justify-content-between">
                <div class="card-icon text-muted"><i class="fas fa-sort-amount-up fs-14"></i></div>
                <h4 class="card-title"><?php echo app('translator')->get('locale.temperature', ['suffix'=>'s']); ?></h4>
                <div class="card-addon dropdown"></div>
            </div>
            <div class="card-body">
                <div class="border-bottom hstack justify-content-center gap-4 pb-3">
                    <div class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <span class="text-primary fs-22 me-2"><i class="fas fa-arrow-circle-up"></i></span>
                            <h4 class="display-6 mb-0">28</h4>
                        </div>
                        <p class="text-muted mb-0"><?php echo app('translator')->get('locale.high'); ?></p>
                    </div>

                    <div class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <span class="text-danger fs-22 me-2"><i class="fas fa-arrow-circle-down"></i></span>
                            <h4 class="display-6 mb-0">32</h4>
                        </div>
                        <p class="text-muted mb-0"><?php echo app('translator')->get('locale.low'); ?></p>
                    </div>
                </div>
                <div class="pt-3">
                    <?php $__currentLoopData = $temperatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h5 class="fs-6 mb-0"><i class="fas fa-arrow-circle-<?php echo e($item->degree > 37 ? 'up' : 'down'); ?> text-<?php echo e($item->degree > 37 ? 'danger' : 'primary'); ?> me-2"></i>Invoice 1</h5>
                        <p class="text-muted mb-0">+1,235</p>
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="card" style="height: 416px; overflow: hidden auto;" data-simplebar="">
            <div class="card-header card-header-bordered">
                <div class="card-icon text-muted"><i class="fas fa-money-bill fs14"></i></div>
                <h3 class="card-title">5 <?php echo app('translator')->get('locale.last_payments'); ?></h3>
            </div>
            <div class="card-body">
                <div class="rich-list rich-list-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex-column align-items-stretch">
                        <div class="rich-list-item">
                            <div class="rich-list-prepend">
                                <div class="avatar avatar-xs">
                                    <div class=""><img src="<?php echo e(asset('images/users/avatar-1.png')); ?>" alt="Avatar image" class="avatar-2xs" /></div>
                                </div>
                            </div>
                            <div class="rich-list-content">
                                <h4 class="rich-list-title mb-1"><?php echo app('translator')->get('locale.billing', ['suffix'=>'']); ?> : <?php echo e($item->billing->ref); ?></h4>
                                <p class="rich-list-subtitle mb-0"><?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at))); ?> | <?php echo e(moneyFormat($item->amount)); ?> | <?php echo e($item->method); ?></p>
                            </div>
                            <div class="rich-list-append"><a class="btn btn-sm btn-label-primary" href="<?php echo e(route('stocks.show', $item->stock_id)); ?>"><?php echo app('translator')->get('locale.stock', ['suffix'=>'']); ?></a></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted text-center"><?php echo app('translator')->get('locale.empty'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end row --><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/dashboard.blade.php ENDPATH**/ ?>