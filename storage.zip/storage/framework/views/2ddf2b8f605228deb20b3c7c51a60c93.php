<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta content="Cool AgriStock, Food Storage" name="description" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta content="Cool AgriStock" name="author" />

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">

        <script src="<?php echo e(asset('js/pages/layout.js')); ?>"></script>

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('libs/simplebar/simplebar.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
        
    </head>
    <body>
        <div class="container-fluid authentication-bg overflow-hidden">
            <div class="bg-overlay"></div>
            <div class="row align-items-center justify-content-center min-vh-100">
                <div class="col-10 col-md-6 col-lg-4 col-xxl-3">
                    <div class="card card-top-primary card-bottom-primary mb-0">
                        <div class="card-body">
                            <div class="text-center">
                                <a href="<?php echo e(route('welcome')); ?>" class="logo-dark">
                                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" height="80" class="auth-logo logo-dark mx-auto">
                                </a>
                                <a href="<?php echo e(route('welcome')); ?>" class="logo-dark">
                                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" height="80" class="auth-logo logo-light mx-auto">
                                </a>                                
                            </div>
                            <div class="p-2 mt-2">
                                <?php echo e($slot); ?>

                            </div>
                            <div class="mt-3 text-center">
                                <p>© <script>document.write(new Date().getFullYear())</script> Cool AgriStock.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/metismenu/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/node-waves/waves.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/layouts/auth.blade.php ENDPATH**/ ?>