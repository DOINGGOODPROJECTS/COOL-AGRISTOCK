<footer class="footer">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © <?php echo e(env('APP_NAME')); ?>.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\agristock.com\resources\views/components/footer.blade.php ENDPATH**/ ?>