<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
    <link href="<?php echo e(asset('libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"><?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?></h4>
                <?php if(isGroupAuthorized([1, 2])): ?>
                <div class="page-title-right">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#new-stock"><i class="fas fa-cart-plus"></i> <?php echo app('translator')->get('locale.new', ['param'=>__('locale.stock', ['suffix'=>''])]); ?></button>
                </div>
                <?php endif; ?>                
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="datatable-buttons" class="table table-hover table-bordered table-striped dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <th>#</th>
                            <th><?php echo app('translator')->get('locale.created_at'); ?></th>
                            <th><?php echo app('translator')->get('locale.ref'); ?></th>
                            <th><?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?></th>
                            <th><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?></th>
                            <th><?php echo app('translator')->get('locale.qty'); ?></th>
                            <th><?php echo app('translator')->get('locale.storage_duration'); ?></th>
                            <th><?php echo app('translator')->get('locale.actions'); ?></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at))); ?></td>
                                <td><?php echo e($item->ref); ?></td>
                                <td><?php echo e($item->customer->name); ?></td>
                                <td><?php echo e($item->storage->name); ?></td>
                                <td><?php echo e($item->qty + $item->details->sum('qty')); ?> kg</td>
                                <td class=""><?php echo e(date('d/m/Y', strtotime($item->created_at->addDays($item->expired_at))) ." / ".$item->expired_at); ?> <?php echo app('translator')->get('locale.days'); ?></td>
                                <td>
                                    <a style="display: inline-block" class="btn btn-label-<?php echo e($item->created_at->addDays($item->expired_at) >= now() ? 'success' : 'danger'); ?>" href="<?php echo e(route('stocks.show', $item->id)); ?>" title="<?php echo app('translator')->get('locale.details'); ?>"><i class="fas fa-folder-open"></i></a>
                                    <?php if(isGroupAuthorized([1, 2])): ?>
                                        <?php if($item->qty == 0): ?>
                                        <div class="row icon-demo-content" style="display: inline-block" title="<?php echo app('translator')->get('locale.released'); ?>">
                                            <div class="col-2">
                                                <i class="fas fa-check text-primary"></i>
                                            </div>
                                        </div>                                        
                                        <?php else: ?>
                                        <a style="display: inline-block" class="btn btn-label-info" href="<?php echo e(route('stocks.edit', $item->id)); ?>"><i class="fas fa-edit"></i></a>
                                        <form action="<?php echo e(route('stocks.destroy', $item->id)); ?>" method="post" style="display: inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-label-danger" onclick="if(!confirm('Confirmez-Vous cette Suppression ?')) return false"><i class="fa fa-trash"></i></button>
                                        </form>
                                        <?php endif; ?>                                    
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->
    <form action="<?php echo e(route('stocks.store')); ?>" method="post" id="form">
        <div class="modal fade" id="new-stock">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header bg-primary-subtle">
                        <h5 class="modal-title"><?php echo app('translator')->get('locale.stock', ['suffix'=>'']); ?></h5>
                    </div>
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-8 col-sm-12 col-xs-12 mx-auto">
                                <div class="d-grid gap-3 mb-2">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <input type="number" class="form-control" id="qty" name="qty" placeholder="Ex: 20" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.qty'); ?> (kg)</label>
                                            </div>                                  
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <input type="number" class="form-control" id="expired_at" name="expired_at" placeholder="Ex: 30" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.storage_duration'); ?> (<?php echo app('translator')->get('locale.days'); ?>)</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <select class="form-select" name="customer_id" aria-label="<?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?>" required>
                                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="customerId"><?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?></label>
                                            </div>                                
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <select class="form-select" name="storage_id" aria-label="<?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?>" id="storageId" required>
                                                    <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" accesskey="<?php echo e($item->available()); ?>"><?php echo e($item->name." - ".$item->location." - Restant: ".$item->available()."Kg"); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="storageId"><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?></label>
                                            </div>
                                        </div>
                                    </div>   
                                </div>
                                
                                <div class="card border">
                                    <div class="card-header bg-primary-subtle">
                                        <h3 class="card-title"><?php echo app('translator')->get('locale.details'); ?></h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-2">
                                            <div class="row">
                                                <div class="col-md-7 col-sm-7 col-xs-12">
                                                    <div class="form-floating">
                                                        <select class="form-select form-select-sm" id="product_name" aria-label="<?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?>" required>
                                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" title="<?php echo e($item->expired_at); ?>"><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <label for="productId"><?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-5 col-sm-5 col-xs-12">
                                                    <div class="input-group">
                                                        <div class="form-floating">
                                                            <input type="number" id="product_qty" class="form-control" placeholder="<?php echo app('translator')->get('locale.qty'); ?>"> 
                                                            <label for="product_qty"><?php echo app('translator')->get('locale.qty'); ?> (kg)</label>
                                                        </div>
                                                        <button class="btn btn-label-primary btn-icon" type="button" id="new-row"><i class="fa fa-plus-circle"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <table class="table table-hover table-bordered table-striped">
                                                    <thead>
                                                        <th><?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?></th>
                                                        <th><?php echo app('translator')->get('locale.qty'); ?> (kg)</th>
                                                        <th><?php echo app('translator')->get('locale.expiration_possible'); ?> (<?php echo app('translator')->get('locale.days'); ?>)</th>
                                                        <th><?php echo app('translator')->get('locale.actions'); ?></th>
                                                    </thead>
                                                    <tbody id="tbody"></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary"><?php echo app('translator')->get('locale.submit'); ?> <i class="fas fa-check"></i></button> 
                        <button class="btn btn-outline-danger" data-bs-dismiss="modal" type="button"><?php echo app('translator')->get('locale.close'); ?> <i class="mdi mdi-close"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php $__env->startPush('scripts'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- buttons examples -->
    <script src="<?php echo e(asset('libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('js/pages/datatables-extension.init.js')); ?>"></script>
    <script>
        localStorage.setItem('total', 0);
    </script>
    <script src="<?php echo e(asset('js/details.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/admin/stocks.blade.php ENDPATH**/ ?>