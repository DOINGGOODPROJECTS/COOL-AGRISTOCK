<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"><?php echo app('translator')->get('locale.stock', ['suffix'=>'']); ?></h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('stocks.index')); ?>"><?php echo app('translator')->get('locale.stock', ['suffix'=>'s']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo app('translator')->get('locale.edit'); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('stocks.update', $stock->id)); ?>" method="post" id="form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-12">
                                <div class="d-grid gap-3 mb-2">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <input type="number" class="form-control" id="qty" name="qty" value="<?php echo e($stock->qty); ?>" placeholder="Ex: 20" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.qty'); ?> (kg)</label>
                                            </div>                                  
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <input type="number" class="form-control" id="expired_at" name="expired_at" value="<?php echo e($stock->expired_at); ?>" placeholder="Ex: 30" required/> <label for="floatingInput"><?php echo app('translator')->get('locale.expired_at'); ?> (<?php echo app('translator')->get('locale.days'); ?>)</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <select class="form-select" name="customer_id" aria-label="<?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?>" required>
                                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e($stock->customer_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="customerId"><?php echo app('translator')->get('locale.customer', ['suffix'=>'']); ?></label>
                                            </div>                                
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="form-floating">
                                                <select class="form-select" name="storage_id" id="storageId" aria-label="<?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?>" required>
                                                    <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e($stock->storage_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <label for="storageId"><?php echo app('translator')->get('locale.storage', ['suffix'=>'']); ?></label>
                                            </div>
                                        </div>
                                    </div>   
                                </div>
                                
                                <div class="card border mb-2">
                                    <div class="card-header bg-primary-subtle">
                                        <h3 class="card-title"><?php echo app('translator')->get('locale.details'); ?></h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-2">
                                            <div class="row">
                                                <div class="col-md-7 col-sm-7 col-xs-12">
                                                    <div class="form-floating">
                                                        <select class="form-select form-select-sm" id="product_name" aria-label="<?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?>" required>
                                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <label for="productId"><?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-md-5 col-sm-5 col-xs-12">
                                                    <div class="input-group">
                                                        <div class="form-floating">
                                                            <input type="number" id="product_qty" class="form-control" placeholder="<?php echo app('translator')->get('locale.qty'); ?>"> 
                                                            <label for="product_qty"><?php echo app('translator')->get('locale.qty'); ?> (kg)</label>
                                                        </div>
                                                        <button class="btn btn-label-primary btn-icon" type="button" id="new-row"><i class="fa fa-plus-circle"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <table class="table table-hover table-bordered table-striped">
                                                    <thead>
                                                        <th><?php echo app('translator')->get('locale.product', ['suffix'=>'']); ?></th>
                                                        <th><?php echo app('translator')->get('locale.qty'); ?> (kg)</th>
                                                        <th><?php echo app('translator')->get('locale.expiration_possible'); ?></th>
                                                        <th><?php echo app('translator')->get('locale.actions'); ?></th>
                                                    </thead>
                                                    <tbody id="tbody">
                                                        <?php $__currentLoopData = $stock->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($item->product->name); ?></td>
                                                            <td><?php echo e($item->qty); ?></td>
                                                            <td>[<?php echo e($item->product->min_expired_at . (!is_null($item->max_expired_at) ? ' - '.$item->max_expired_at : '')); ?>] <?php echo app('translator')->get('locale.days'); ?> => <?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at->addDays($item->product->min_expired_at)))); ?></td>
                                                            <td class="text-center"><i class="fa fa-trash text-danger" onclick="deleter(this)"></i></td>
                                                            <input type="hidden" name="product_id[]" value="<?php echo e($item->product->id); ?>" />
                                                            <input type="hidden" name="qtys[]" value="<?php echo e($item->qty); ?>" />
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-grid">
                                    <button class="btn btn-label-primary"><?php echo app('translator')->get('locale.submit'); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> 
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        localStorage.setItem('total', <?php echo e($stock->details->sum('qty')); ?>);
    </script>
    <script src="<?php echo e(asset('js/details.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/admin/edit-stock.blade.php ENDPATH**/ ?>