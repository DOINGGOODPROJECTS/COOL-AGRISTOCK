<button <?php echo e($attributes->merge(['type' => 'submit'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\agristock.com\resources\views/components/btn.blade.php ENDPATH**/ ?>